﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;

namespace WindPowerForecasterAPI.Repository
{
    public class WindPowerRepository
    {
        public WindPowerForecasterDBContext _dbContext;

        public WindPowerRepository(WindPowerForecasterDBContext dbContext)
        {
            _dbContext = dbContext;
        }
    }
}
