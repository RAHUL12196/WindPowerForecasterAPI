﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;

namespace WindPowerForecasterAPI.Repository
{
    public class WindTurbineRepository
    {
        public WindPowerForecasterDBContext _dbContext;

        public WindTurbineRepository(WindPowerForecasterDBContext dbContext)
        {
            _dbContext = dbContext;
        }
    }
}
