﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;

namespace WindPowerForecasterAPI.Repository
{
    public class UserTableRepository
    {
        public WindPowerForecasterDBContext _dbContext;

        public UserTableRepository(WindPowerForecasterDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<UserTable> GetUsers()
        {
            return _dbContext.UserTable;
        }

        public IEnumerable<UserTable> GetUserByID(string userID)
        {
            return _dbContext.UserTable.Where(i => i.UserId == userID);
        }
        public UserTable AddUser(UserTable user)
        {
            _dbContext.UserTable.Add(user);
            _dbContext.SaveChanges();
            return user;
        }
    }
}
