﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;

namespace WindPowerForecasterAPI.Repository
{
    public class CompanyRepository
    {
        public WindPowerForecasterDBContext _dbContext;

        public CompanyRepository(WindPowerForecasterDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<Company> GetCompanies()
        {
            return _dbContext.Company;
        }

        public IEnumerable<Company> GetCompanyByID(string companyID)
        {
            return _dbContext.Company.Where(i => i.CompanyId == companyID);
        }

        public Company AddCompany(Company company)
        {
            _dbContext.Company.Add(company);
            _dbContext.SaveChanges();
            return company;
        }
    }
}
