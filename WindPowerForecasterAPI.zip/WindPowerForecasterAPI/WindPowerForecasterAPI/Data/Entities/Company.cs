﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace WindPowerForecasterAPI.Data.Entities
{
    public partial class Company
    {
        public Company()
        {
            UserTable = new HashSet<UserTable>();
            WindTurbine = new HashSet<WindTurbine>();
        }

        public string CompanyId { get; set; }
        public string CompanyName { get; set; }

        public virtual ICollection<UserTable> UserTable { get; set; }
        public virtual ICollection<WindTurbine> WindTurbine { get; set; }
    }
}
