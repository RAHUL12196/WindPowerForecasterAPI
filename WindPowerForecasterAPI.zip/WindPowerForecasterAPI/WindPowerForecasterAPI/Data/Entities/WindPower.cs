﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace WindPowerForecasterAPI.Data.Entities
{
    public partial class WindPower
    {
        public int TurbineId { get; set; }
        public int Hour { get; set; }
        public decimal WindPower1 { get; set; }

        public virtual WindTurbine Turbine { get; set; }
    }
}
