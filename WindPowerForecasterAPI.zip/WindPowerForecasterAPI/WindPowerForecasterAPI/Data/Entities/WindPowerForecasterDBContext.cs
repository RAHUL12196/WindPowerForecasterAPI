﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace WindPowerForecasterAPI.Data.Entities
{
    public partial class WindPowerForecasterDBContext : DbContext
    {
        public WindPowerForecasterDBContext()
        {
        }

        public WindPowerForecasterDBContext(DbContextOptions<WindPowerForecasterDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Company> Company { get; set; }
        public virtual DbSet<UserTable> UserTable { get; set; }
        public virtual DbSet<WindPower> WindPower { get; set; }
        public virtual DbSet<WindTurbine> WindTurbine { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=WindPowerForecasterDB;Trusted_Connection=True;MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Company>(entity =>
            {
                entity.Property(e => e.CompanyId)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CompanyName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserTable>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__UserTabl__1788CC4C22013502");

                entity.Property(e => e.UserId)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CompanyId)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UserType)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.UserTable)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_UserTable_Company");
            });

            modelBuilder.Entity<WindPower>(entity =>
            {
                entity.HasKey(e => new { e.TurbineId, e.Hour })
                    .HasName("pk_TurbineId_Hour");

                entity.Property(e => e.WindPower1)
                    .HasColumnName("WindPower")
                    .HasColumnType("decimal(6, 2)");

                entity.HasOne(d => d.Turbine)
                    .WithMany(p => p.WindPower)
                    .HasForeignKey(d => d.TurbineId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_WindPower_WindTurbine");
            });

            modelBuilder.Entity<WindTurbine>(entity =>
            {
                entity.HasKey(e => e.TurbineId)
                    .HasName("pk_TurbineId");

                entity.Property(e => e.City)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CompanyId)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Latitude).HasColumnType("decimal(4, 2)");

                entity.Property(e => e.Longitude).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.State)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TurbineRadius).HasColumnType("decimal(5, 2)");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.WindTurbine)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_WindTurbine_Company");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
