﻿using GraphQL;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.GraphQL.Types;
using WindPowerForecasterAPI.Repository;

namespace WindPowerForecasterAPI.Data.GraphQL
{
    public class WindPowerForecasterQuery : ObjectGraphType
    {
        public WindPowerForecasterQuery(CompanyRepository companyRepository, UserTableRepository userTableRepository)
        {
            Field<ListGraphType<CompanyType>>(
                "companies",
                resolve: context => companyRepository.GetCompanies()
                );

            Field<ListGraphType<CompanyType>>(
               "companyById",
               arguments: new QueryArguments(new QueryArgument<NonNullGraphType<StringGraphType>> { Name = "companyId" }),
               resolve: context =>
               {
                   var companyId = context.GetArgument<string>("companyId");
                   return companyRepository.GetCompanyByID(companyId);
               });

            Field<ListGraphType<UserTableType>>(
                            "users",
                            resolve: context => userTableRepository.GetUsers()
                            );

            Field<ListGraphType<UserTableType>>(
               "userById",
               arguments: new QueryArguments(new QueryArgument<NonNullGraphType<StringGraphType>> { Name = "userId" }),
               resolve: context =>
               {
                   var userId = context.GetArgument<string>("userId");
                   return userTableRepository.GetUserByID(userId);
               });
        }
    }
}
