﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WindPowerForecasterAPI.Data.GraphQL.Types
{
    public class UserTableInputType : InputObjectGraphType
    {
        public UserTableInputType()
        {
            Name = "userInput";
            Field<NonNullGraphType<StringGraphType>>("UserId");
            Field<NonNullGraphType<StringGraphType>>("Password");
            Field<NonNullGraphType<StringGraphType>>("UserName");
            Field<NonNullGraphType<StringGraphType>>("UserType");
            Field<NonNullGraphType<StringGraphType>>("CompanyId");
        }
    }
}
