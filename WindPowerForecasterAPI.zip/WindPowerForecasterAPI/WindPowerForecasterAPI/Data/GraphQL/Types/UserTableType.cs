﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;

namespace WindPowerForecasterAPI.Data.GraphQL.Types
{
    public class UserTableType: ObjectGraphType<UserTable>
    {
        public UserTableType()
        {
            Field(t => t.UserId);
            Field(t => t.Password);
            Field(t => t.UserName);
            Field(t => t.UserType);
            Field(t => t.CompanyId);
        }
    }
}
