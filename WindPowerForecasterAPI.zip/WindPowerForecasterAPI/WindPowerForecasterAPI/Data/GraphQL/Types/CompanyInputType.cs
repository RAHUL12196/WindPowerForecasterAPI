﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WindPowerForecasterAPI.Data.GraphQL.Types
{
    public class CompanyInputType : InputObjectGraphType
    {
        public CompanyInputType()
        {
            Name = "companyInput";
            Field<NonNullGraphType<StringGraphType>>("CompanyId");
            Field<NonNullGraphType<StringGraphType>>("CompanyName");

        }
    }
}
