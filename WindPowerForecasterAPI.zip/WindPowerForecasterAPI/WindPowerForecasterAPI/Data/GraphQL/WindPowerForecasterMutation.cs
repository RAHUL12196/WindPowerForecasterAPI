﻿using GraphQL;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;
using WindPowerForecasterAPI.Data.GraphQL.Types;
using WindPowerForecasterAPI.Repository;

namespace WindPowerForecasterAPI.Data.GraphQL
{
    public class WindPowerForecasterMutation : ObjectGraphType
    {
        public WindPowerForecasterMutation(CompanyRepository companyRepository, UserTableRepository userTableRepository)
        {
            Field<CompanyType>(
            "addCompany",
            arguments: new QueryArguments(new QueryArgument<NonNullGraphType<CompanyInputType>> { Name = "company" }),
            resolve: context =>
            {
                var company = context.GetArgument<Company>("company");
                return companyRepository.AddCompany(company);
            });

            Field<UserTableType>(
            "addUser",
            arguments: new QueryArguments(new QueryArgument<NonNullGraphType<UserTableInputType>> { Name = "user" }),
            resolve: context =>
            {
                var user = context.GetArgument<UserTable>("user");
                return userTableRepository.AddUser(user);
            });
        }
    }
}
